// Temporary workaraund
declare var CKEDITOR: any;
declare var $q: any;
declare var moment: any;
declare var window: Window;

declare namespace _ {
    interface LoDashStatic {
        zipBy(a, b, c?): any;
    }
}
